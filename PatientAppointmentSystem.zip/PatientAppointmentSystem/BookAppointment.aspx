﻿<!DOCTYPE html>
<html>
<head runat="server">
    <title>Book Appointment</title>

    <style>
        body {
            font-family: Arial;
            background-color: #f5f5f5;
        }

        .box {
            width: 400px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
        }

        h2 {
            text-align: center;
            color: #2196F3;
        }

        label {
            display: block;
            margin-top: 15px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
        }

        .btn {
            width: 100%;
            margin-top: 20px;
            padding: 12px;
            background-color: #2196F3;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <form id="form1" runat="server">

        <div class="box">

            <h2>Book Appointment</h2>

            <label>Patient Name</label>
            <asp:TextBox ID="txtName" runat="server"
                placeholder="Enter your name"></asp:TextBox>

            <label>Email</label>
            <asp:TextBox ID="txtEmail" runat="server"
                TextMode="Email"
                placeholder="Enter your email"></asp:TextBox>

            <label>Select Doctor</label>
            <asp:DropDownList ID="ddlDoctor" runat="server">
                <asp:ListItem>Dr. Arun Kumar - General Physician</asp:ListItem>
                <asp:ListItem>Dr. Priya - Dermatologist</asp:ListItem>
                <asp:ListItem>Dr. Karthik - Cardiologist</asp:ListItem>
                <asp:ListItem>Dr. Divya - Pediatrician</asp:ListItem>
            </asp:DropDownList>

            <label>Appointment Date</label>
            <asp:TextBox ID="txtDate" runat="server"
                TextMode="Date"></asp:TextBox>

            <label>Appointment Time</label>
            <asp:TextBox ID="txtTime" runat="server"
                TextMode="Time"></asp:TextBox>

        
           <asp:Button ID="Button1" runat="server"
            Text="Book Appointment"
             OnClientClick="alert('Appointment Booked Successfully!'); return false;" />

        </div>

    </form>
</body>
</html>