﻿<!DOCTYPE html>
<html>
<head runat="server">
    <title>My Appointments</title>

    <style>
        body {
            font-family: Arial;
            background-color: #f5f5f5;
        }

        .box {
            width: 80%;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
        }

        h2 {
            text-align: center;
            color: #2196F3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #2196F3;
            color: white;
        }
    </style>
</head>

<body>
    <form id="form1" runat="server">

        <div class="box">

            <h2>My Appointments</h2>

            <table>
                <tr>
                    <th>Patient Name</th>
                    <th>Doctor</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                </tr>

                <tr>
                    <td>Sample Patient</td>
                    <td>Dr. Arun Kumar</td>
                    <td>01/10/2026</td>
                    <td>10:00 AM</td>
                    <td>Pending</td>
                </tr>
            </table>

        </div>

    </form>
</body>
</html>