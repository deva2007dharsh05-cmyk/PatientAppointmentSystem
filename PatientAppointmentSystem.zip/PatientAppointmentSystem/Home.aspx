﻿<%@ Page Language="C#" %>

<!DOCTYPE html>
<html>
<head>
    <title>Patient Appointment Booking</title>
</head>
<body>

    <h1>Patient Appointment Booking System</h1>

    <h2>Welcome!</h2>

    <p>Book your doctor appointment easily.</p>

    <a href="Register.aspx">Register</a><br /><br />
    <a href="Login.aspx">Login</a><br /><br />
    <a href="Doctors.aspx">Doctors</a><br /><br />
    <a href="BookAppointment.aspx">Book Appointment</a>

</body>
</html>