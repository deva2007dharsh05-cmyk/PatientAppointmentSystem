﻿<%@ Application Codebehind="Global.asax.cs" Inherits="PatientAppointmentSystem.Global" Language="C#" %>
