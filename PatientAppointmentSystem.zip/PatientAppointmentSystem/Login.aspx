﻿<!DOCTYPE html>
<html>
<head runat="server">
    <title>Patient Login</title>

    <style>
        body {
            font-family: Arial;
            background-color: #f4f8fb;
            margin: 0;
        }

        .header {
            background-color: #1976d2;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .login-box {
            width: 350px;
            margin: 60px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
        }

        h2 {
            text-align: center;
            color: #1976d2;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 8px 0 15px;
            box-sizing: border-box;
        }

        .btn {
            width: 100%;
            background-color: #1976d2;
            color: white;
            border: none;
            padding: 12px;
        }
    </style>
</head>

<body>

<form id="form1" runat="server">

    <div class="header">
        <h1>Patient Appointment Booking System</h1>
    </div>

    <div class="login-box">

        <h2>Patient Login</h2>

        <label>Email</label>
        <input type="email" placeholder="Enter your email" />

        <label>Password</label>
        <input type="password" placeholder="Enter your password" />

        <button type="button" onclick="alert('Login Successful!')">Login</button>

    </div>

</form>

</body>
</html>