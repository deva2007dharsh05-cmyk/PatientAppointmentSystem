﻿<!DOCTYPE html>
<html>
<head>
    <title>Patient Registration</title>

    <style>
        body {
            font-family: Arial;
            background-color: #f2f2f2;
        }

        .box {
            width: 350px;
            margin: 80px auto;
            padding: 25px;
            background: white;
            border-radius: 10px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #1976d2;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>

<body>

<div class="box">

    <h2>Patient Registration</h2>

    <input type="text" placeholder="Name">

    <input type="email" placeholder="Email">

    <input type="text" placeholder="Phone Number">

    <input type="password" placeholder="Password">

    <button onclick="registerUser()">Register</button>

</div>

<script>
    function registerUser() {
        alert("Registration Successful!");
    }
</script>

</body>
</html><!DOCTYPE html>
<html>
<head>
    <title>Patient Registration</title>

    <style>
        body {
            font-family: Arial;
            background-color: #f2f2f2;
        }

        .box {
            width: 350px;
            margin: 80px auto;
            padding: 25px;
            background: white;
            border-radius: 10px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #1976d2;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>

<body>

<div class="box">

    <h2>Patient Registration</h2>

    <input type="text" placeholder="Name">

    <input type="email" placeholder="Email">

    <input type="text" placeholder="Phone Number">

    <input type="password" placeholder="Password">

    <button onclick="registerUser()">Register</button>

</div>

<script>
    function registerUser() {
        alert("Registration Successful!");
    }
</script>

</body>
</html>