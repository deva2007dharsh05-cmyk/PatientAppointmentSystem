﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Doctors.aspx.cs" Inherits="PatientAppointmentSystem.Doctors" %>
<!DOCTYPE html>
<html>
<head runat="server">
    <title>Our Doctors</title>

    <style>
        body {
            font-family: Arial;
            background-color: #f4f8fb;
            margin: 0;
        }

        .header {
            background-color: #1976d2;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .container {
            width: 80%;
            margin: 40px auto;
            text-align: center;
        }

        .doctor {
            display: inline-block;
            background: white;
            width: 220px;
            margin: 15px;
            padding: 20px;
            border-radius: 10px;
        }

        h2 {
            color: #1976d2;
        }

        .btn {
            display: inline-block;
            background-color: #1976d2;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>

<body>

<form id="form1" runat="server">

    <div class="header">
        <h1>Our Doctors</h1>
        <p>Choose a doctor for your appointment</p>
    </div>

    <div class="container">

        <div class="doctor">
            <h2>Dr. Arun Kumar</h2>
            <p>General Physician</p>
            <a class="btn" href="Login.aspx">Book Appointment</a>
        </div>

        <div class="doctor">
            <h2>Dr. Priya</h2>
            <p>Dermatologist</p>
            <a class="btn" href="Login.aspx">Book Appointment</a>
        </div>

        <div class="doctor">
            <h2>Dr. Karthik</h2>
            <p>Cardiologist</p>
            <a class="btn" href="Login.aspx">Book Appointment</a>
        </div>

        <div class="doctor">
            <h2>Dr. Divya</h2>
            <p>Pediatrician</p>
            <a class="btn" href="Login.aspx">Book Appointment</a>
        </div>

    </div>

</form>

</body>
</html>
