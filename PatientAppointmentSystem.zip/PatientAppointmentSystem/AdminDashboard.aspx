﻿<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>

    <style>
        body {
            margin: 0;
            font-family: Arial;
            background: #f4f7fb;
        }

        .header {
            background: #1976d2;
            color: white;
            padding: 25px;
            text-align: center;
        }

        .container {
            width: 90%;
            margin: 35px auto;
        }

        .welcome {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 10px #ddd;
            margin-bottom: 25px;
        }

        .cards {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .card {
            background: white;
            width: 200px;
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 3px 10px #ddd;
        }

        .card h3 {
            color: #1976d2;
        }

        .button {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 18px;
            background: #1976d2;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>

<body>

<div class="header">
    <h1>Admin Dashboard</h1>
    <p>Patient Appointment Booking System</p>
</div>

<div class="container">

    <div class="welcome">
        <h2>Welcome, Admin!</h2>
        <p>Manage the patient appointment booking system easily.</p>
    </div>

    <div class="cards">

        <div class="card">
            <h3>Register</h3>
            <p>Patient Registration</p>
            <a class="button" href="Register.aspx">Open</a>
        </div>

        <div class="card">
            <h3>Login</h3>
            <p>Patient Login</p>
            <a class="button" href="Login.aspx">Open</a>
        </div>

        <div class="card">
            <h3>Doctors</h3>
            <p>View Doctors</p>
            <a class="button" href="Doctors.aspx">Open</a>
        </div>

        <div class="card">
            <h3>Appointments</h3>
            <p>Book Appointment</p>
            <a class="button" href="BookAppointment.aspx">Open</a>
        </div>

        <div class="card">
            <h3>My Appointments</h3>
            <p>View Appointments</p>
            <a class="button" href="MyAppointments.aspx">Open</a>
        </div>

    </div>

</div>

</body>
</html>